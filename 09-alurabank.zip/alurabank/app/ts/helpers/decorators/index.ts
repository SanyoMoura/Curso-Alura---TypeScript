export * from './logarTempoDeExecucao';
export * from './domInject';